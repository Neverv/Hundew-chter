# DogGuard Beta 0.1.0

DogGuard is a Flutter application for dog owners.

## Included in this starter beta
- Login / registration demo flow
- Dashboard
- Dog profiles
- Health records
- Rescue foundation
- Expert directory
- Profile/settings
- Founding Pack / beta feedback

## Run on Windows
1. Install Flutter and Android Studio.
2. Run `flutter pub get`.
3. Run `flutter run -d windows`.

## Android
Run `flutter run` on an Android emulator/device.

## iOS
Requires macOS + Xcode for signing and TestFlight distribution.

Package target: `com.dogguard.app`
Version: `0.1.0+1`

This build is a functional UI prototype. Production authentication, backend storage,
maps, notifications and real expert verification must be connected before public release.
