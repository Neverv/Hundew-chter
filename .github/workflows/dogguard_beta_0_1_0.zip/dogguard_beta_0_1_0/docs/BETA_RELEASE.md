# DogGuard Beta Release 0.1.0+1

Targets:
- Android: Google Play Internal Testing
- iOS: TestFlight

Package identifier:
com.dogguard.app

The first 100 pilot users are the DogGuard Founding Pack.

Production requirements still to implement:
- real authentication/backend
- secure database policies
- cloud storage
- push notifications
- maps/location services
- real expert verification
- app store privacy metadata
- production signing
